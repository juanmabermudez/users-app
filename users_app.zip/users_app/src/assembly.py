from adapters.memory.user_repository_adapter import InMemoryUserRepositoryAdapter
from domain.use_cases.base_use_case import BaseUseCase
from domain.use_cases.create_user_use_case import CreateUserUseCase
from domain.use_cases.delete_user_use_case import DeleteUserUseCase
from domain.use_cases.get_user_use_case import GetUserUseCase
from domain.use_cases.get_users_use_case import GetAllUsersUseCase
from domain.use_cases.update_user_use_case import UpdateUserUseCase
from domain.use_cases.authenticate_user_use_case import AuthenticateUserUseCase
from domain.use_cases.count_users_use_case import CountUsersUseCase
from domain.use_cases.get_current_user_use_case import GetCurrentUserUseCase
from domain.use_cases.reset_users_use_case import ResetUsersUseCase

repository: InMemoryUserRepositoryAdapter = InMemoryUserRepositoryAdapter()


def build_create_user_use_case() -> BaseUseCase:
    """Get create user use case."""
    return CreateUserUseCase(repository)


def build_get_user_use_case() -> BaseUseCase:
    """Get user use case."""
    return GetUserUseCase(repository)


def build_get_users_use_case() -> BaseUseCase:
    """Get users use case."""
    return GetAllUsersUseCase(repository)


def build_update_user_use_case() -> BaseUseCase:
    """Update user use case."""
    return UpdateUserUseCase(repository)


def build_delete_user_use_case() -> BaseUseCase:
    """Get delete user use case."""
    return DeleteUserUseCase(repository)


def build_authenticate_user_use_case() -> AuthenticateUserUseCase:
    """Get authenticate user use case."""
    return AuthenticateUserUseCase(repository)


def build_count_users_use_case() -> CountUsersUseCase:
    """Get count users use case."""
    return CountUsersUseCase(repository)

from domain.use_cases.get_current_user_use_case import GetCurrentUserUseCase
# instancia ÚNICA para compartir tokens
_auth_use_case = AuthenticateUserUseCase(repository)

def build_authenticate_user_use_case() -> AuthenticateUserUseCase:
    return _auth_use_case  # devuelve la misma instancia

def build_get_current_user_use_case() -> GetCurrentUserUseCase:
    return GetCurrentUserUseCase(_auth_use_case)


def build_reset_users_use_case() -> ResetUsersUseCase:
    return ResetUsersUseCase(repository)

